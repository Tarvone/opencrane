{{- define "opencrane.migrate.job" -}}
{{- if .Values.clustertenantManager.migrationJob.enabled }}
# Run Prisma migrations on EVERY install/upgrade, independent of the opencrane-ui
# pod template. The opencrane-ui also carries a `db-migrate` initContainer, but an
# initContainer only fires when the pod is (re)created — so a `helm upgrade` whose
# opencrane-ui values are unchanged never rolls the pod and never re-runs migrations.
# That left the schema silently behind whenever the database was recreated under a
# still-running pod (e.g. a CNPG cluster rebuild). This pre-upgrade hook closes that
# gap: it blocks the rollout until `prisma migrate deploy` succeeds against the live
# database, so every deploy reconciles the schema. Idempotent — a no-op when the DB is
# already at the latest migration.
apiVersion: batch/v1
kind: Job
metadata:
  name: {{ include "opencrane.fullname" . }}-opencrane-server-migrate
  labels:
    {{- include "opencrane.labels" . | nindent 4 }}
    app.kubernetes.io/component: opencrane-server-migrate
  annotations:
    "helm.sh/hook": pre-install,pre-upgrade
    "helm.sh/hook-weight": "-5"
    "helm.sh/hook-delete-policy": before-hook-creation,hook-succeeded
spec:
  backoffLimit: {{ .Values.clustertenantManager.migrationJob.backoffLimit }}
  template:
    metadata:
      labels:
        {{- include "opencrane.selectorLabels" . | nindent 8 }}
        app.kubernetes.io/component: opencrane-server-migrate
    spec:
      automountServiceAccountToken: false
      # No serviceAccountName: this is a pre-install/pre-upgrade hook, so it runs BEFORE the
      # chart's own ServiceAccount exists — referencing it would wedge the Job (the pod is
      # rejected for a missing SA, the hook never completes, and `helm install` times out).
      # The migration only needs DB network access (prisma migrate deploy), not k8s RBAC, so
      # the namespace's default ServiceAccount is sufficient.
      restartPolicy: Never
      containers:
        - name: db-migrate
          image: "{{ .Values.clustertenantManager.image.repository }}:{{ .Values.clustertenantManager.image.tag }}"
          imagePullPolicy: {{ .Values.clustertenantManager.image.pullPolicy }}
          command: ["node", "apps/opencrane/dist/scripts/migrate.js"]
          env:
            {{- include "opencrane.clustertenantManagerDatabaseEnv" . | nindent 12 }}
{{- end }}
{{- end }}
